# materialcolorpicker
material design color picker javascript

# usage

    $('input').colorPicker({
        // optional. set input color.
        preview: true,
        // optional. callback when a color selected
        setValue : function(color, txt) {
        }
    });

# online demo

https://codepen.io/anon/pen/YLdMgg

